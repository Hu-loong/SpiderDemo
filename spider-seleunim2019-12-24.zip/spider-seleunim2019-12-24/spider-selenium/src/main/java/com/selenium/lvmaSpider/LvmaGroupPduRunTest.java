package com.selenium.lvmaSpider;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

//跟团游旅游产品页面模板抓取测试
public class LvmaGroupPduRunTest {

    public static void main(String[] args) {
        Document produDoc = LvmaGroupPdu.getHtmlDoc(322, null);
        //System.out.println(produDoc);
        Elements pageAEles = produDoc.getElementsByClass("pagebox").get(0).getElementsByTag("a");
        String pageTotalNum = pageAEles.get(pageAEles.size() - 2).text();
        System.out.println("======================================================");
        System.out.println("总页数："+pageTotalNum);
        Elements pduListEles = produDoc.getElementsByClass("product-item clearfix");
        //获得当前产品模块
        Element currentPduEle = pduListEles.get(1);
        int pduListSize = pduListEles.size();
        System.out.println("产品模块数："+pduListSize);
        String pduType = pduListEles.get(0).getElementsByClass("product-label product-label-alpha").text();
        System.out.println("产品类型："+pduType);
        String route = pduListEles.get(0).getElementsByClass("product-city").get(0).text();
        System.out.println("路线："+route);
        String startCity = currentPduEle.getElementsByClass("product-address").text();
        System.out.println("出发城市："+startCity);
        String priceStr = currentPduEle.getElementsByClass("product-price").get(0).getElementsByTag("em").text();
        Double price = Double.valueOf(priceStr);
        System.out.println("价格："+price);
        Element aEle = currentPduEle.getElementsByClass("product-left").get(0).getElementsByTag("a").get(0);
        String url = aEle.attr("href");
        System.out.println("url："+url);
        String route2 = currentPduEle.getElementsByClass("product-ticket-dropdown").text();
        System.out.println("路线详细："+route2);

    }
}
