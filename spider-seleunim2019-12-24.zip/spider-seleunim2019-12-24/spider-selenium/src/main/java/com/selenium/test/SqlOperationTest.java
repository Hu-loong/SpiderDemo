package com.selenium.test;

import com.selenium.DButils.DataSourceKey;
import com.selenium.DButils.QueryRunnerHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import javax.sql.DataSource;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

public class SqlOperationTest {
    /*//编写处理的逻辑业务
    //QueryRunnerHandler handler = new QueryRunnerHandler(datasourceKey) {
    QueryRunnerHandler handler = new QueryRunnerHandler() {

        //如果执行操作类的，并需要做事务的话，可以考虑使用这个方法
        public void dealSubmit(Connection conn) throws Exception{

            //操作类的要事务的在这里实现,以下代码测试事务，经测可用
            System.out.println(runner);
            String sql = "insert into biz_tag(tag_name,tag_description) values(?,?)";
            runner.update(conn, sql, "admin","admin_descr");
            int i = 1/1;
            System.out.println(i);

        }

        //执行查询业务处理,一般情况下，只需要覆盖其中的一个方法就可，看业务需求
        public void dealQuery(Connection conn) throws Exception {

            String sql = "select * from comments_data";

            List<Map<String,Object>> list = runner.query(conn, sql, new MapListHandler());

            System.out.println(list);

        }

    };*/

    public static void main(String[] args) throws Exception {
        QueryRunnerHandler runner = new QueryRunnerHandler() {
            @Override
            public void dealQuery(Connection conn) throws Exception {
                //super.dealQuery(conn);
                String sql ="select * from lvmapdu where id=10";
                List<Map<String,Object>> list=runner.query(conn,sql,new MapListHandler());
                System.out.println(list);
            }
        };
        Connection connection = runner.getConnection(DataSourceKey.DEFAULT_KEY);
        runner.dealQuery(connection);
    }

}
