package com.selenium.lvmaSpider;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.selenium.DButils.DataSourceKey;
import com.selenium.DButils.ResourceUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class LvmaPduDetailInfo {


    /**
     * 接收url解析出网页文档的HttpClient工具方法
     *
     * @param url
     * @return Documentd对象
     */
    public static Document getHtmlDoc(String url) {
        CloseableHttpClient httpclient = HttpClients.createDefault(); // 创建httpclient实例
        HttpGet httpget = new HttpGet(url); // 创建httpget实例
        CloseableHttpResponse response = null; // 执行get请求
        String content = null;
        try {
            response = httpclient.execute(httpget);
            HttpEntity entity = response.getEntity(); // 获取返回实体
            content = EntityUtils.toString(entity, "gbk");
            response.close(); // 关闭流和释放系统资源
        } catch (IOException e) {
            e.printStackTrace();
        }
        Document doc = Jsoup.parse(content); // 解析网页 得到文档对象
        return doc;
    }

    /**
     * 模拟浏览器操作
     *
     * @param url_web
     * @return
     */
    public static WebDriver getDriver(String url_web) {
        try {
            System.out.println("---");
            // 等待数据加载的时间
            // 为了防止服务器封锁，这里的时间要模拟人的行为，随机且不能太短
            long waitLoadBaseTime = 2000;
            int waitLoadRandomTime = 2000;
            System.out.println("===");
            Random random = new Random(System.currentTimeMillis());
            // 设置 chrome 的路径,直接放在chrome的安装路径即可
            System.out.println("---");
            String chrome = "F:\\ChromeDrive\\chromedriver.exe";
            System.setProperty("webdriver.chrome.driver", chrome);
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--headless");
            WebDriver driver = new ChromeDriver(options);
            driver.get(url_web);
            // 等待页面动态加载完毕
            System.out.println("---");
            Thread.sleep(waitLoadBaseTime + random.nextInt(waitLoadRandomTime));
            return driver;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        QueryRunner runner = new QueryRunner();
        Connection conn = null;
        try {
            conn = LvmaPduDetailInfo.getConnection(DataSourceKey.DEFAULT_KEY);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String querySql = "select * from spider_data_local";
        String updateSql = "update spider_data_local set content= ? where id = ? ";
        try {
            List<Map<String, Object>> listMap = runner.query(conn, querySql, new MapListHandler());
            for (Map<String, Object> map : listMap) {
                Object content = map.get("content");
                int id = (int) map.get("id");
                /*if (id > 5978) {*/

                    List<Map<String, Object>> mapList = (List<Map<String, Object>>) JSON.parse(content.toString());
                    Map<String, Object> mapContent = mapList.get(0);
                    //System.out.println(mapContent.toString());
                    String url = (String) mapContent.get("url");
                    mapContent.get("startCity");
                    Document pduDetailPage = LvmaPduDetailInfo.getHtmlDoc(url);
                    String pduId = pduDetailPage.getElementsByClass("id-num").text();
                    String agency = pduDetailPage.getElementsByClass("id-supp").text();
                    /*Element destEle = null;
                    try {
                        destEle = pduDetailPage.getElementsByClass("info-city").get(0).nextElementSibling();
                    } catch (Exception e) {
                        e.printStackTrace();
                        continue;
                    }*/
                    //Element tDayEle = destEle.nextElementSibling();
                    //详情页显示的总价
                    //String dest = destEle.getElementsByTag("dd").text();//目的地
                    System.out.println("url：" + url);
                    //String tDay = tDayEle.getElementsByTag("dd").text();//出游天数
                    String tPrice = pduDetailPage.getElementsByClass("crred").get(0).getElementsByTag("em").text();
                    mapContent.put("tPrice", tPrice);
                    //mapContent.put("dest", dest);
                    //mapContent.put("tDay", tDay);
                    mapContent.put("pduId", pduId);//产品id
                    mapContent.put("agency", agency);//供应商
                    String contentNew = JSON.toJSONString(mapList);
                    int result = runner.update(conn, updateSql, contentNew, id);
                    System.out.println("更新结果：" + result);
                /*}else {
                    continue;
                }*/
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    /**
     * 获取数据库连接
     *
     * @param ds_key properties
     * @return
     * @throws Exception
     */
    public static Connection getConnection(String ds_key) throws Exception {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        String url = "" + ResourceUtils.getConfigByName(ds_key + ".url");
        String user = "" + ResourceUtils.getConfigByName(ds_key + ".username");
        String password = "" + ResourceUtils.getConfigByName(ds_key + ".password");
        Connection conn = DriverManager.getConnection(url, user, password);
        return conn;
    }
}
