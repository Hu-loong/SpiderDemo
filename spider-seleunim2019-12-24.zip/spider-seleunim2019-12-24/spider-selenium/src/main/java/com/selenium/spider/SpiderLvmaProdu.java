package com.selenium.spider;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;

public class SpiderLvmaProdu {

    public static Document getHtmlDoc(int cityNum, int pageNum) {
        CloseableHttpClient httpclient = HttpClients.createDefault(); // 创建httpclient实例
        String preUrl = "http://s.lvmama.com/route/H";
        String centerUrl = "K440100P";
        String sufferUrl = "?keyword=%E4%BA%91%E5%8D%97&k=0&losc=332207&ict=i#list";
        String urlIndex = preUrl + pageNum + centerUrl + cityNum + sufferUrl;
        System.out.println("合成的Url:" + urlIndex);
        HttpGet httpget = new HttpGet(urlIndex); // 创建httpget实例
        CloseableHttpResponse response = null; // 执行get请求
        String content = null;
        try {
            response = httpclient.execute(httpget);
            HttpEntity entity = response.getEntity(); // 获取返回实体
            content = EntityUtils.toString(entity, "gbk");
            response.close(); // 关闭流和释放系统资源
        } catch (IOException e) {
            e.printStackTrace();
        }
        Document doc = Jsoup.parse(content); // 解析网页 得到文档对象
        return doc;
    }
}
