package com.selenium.lvmaSpider;

import com.alibaba.fastjson.JSON;
import com.selenium.DButils.DataSourceKey;
import com.selenium.DButils.ResourceUtils;
import com.selenium.DButils.UUIDUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//13北京 9上海 14天津 31重庆 256西安 56南京 69杭州 155厦门 258成都 324深圳 322广州 233昆明 308长沙 123沈阳 291武汉
//跟团游旅游产品数据爬取
public class LvmaGetGroupPduImg {
    public static Document getHtmlDoc(Integer cityNum, Integer pageNum) {
        CloseableHttpClient httpclient = HttpClients.createDefault(); // 创建httpclient实例
        String preUrl = "http://s.lvmama.com/group/H";
        String centerUrl = "K310000P";
        String sufferUrl = "?keyword=%E4%BA%91%E5%8D%97&k=0#list";
        if (pageNum == null) {
            pageNum = 1;
        }
        String urlIndex = preUrl + cityNum + centerUrl + pageNum + sufferUrl;
        System.out.println("合成的Url:" + urlIndex);
        HttpGet httpget = new HttpGet(urlIndex); // 创建httpget实例
        CloseableHttpResponse response = null; // 执行get请求
        String content = null;
        try {
            response = httpclient.execute(httpget);
            HttpEntity entity = response.getEntity(); // 获取返回实体
            content = EntityUtils.toString(entity, "gbk");
            response.close(); // 关闭流和释放系统资源
        } catch (IOException e) {
            e.printStackTrace();
        }
        Document doc = Jsoup.parse(content); // 解析网页 得到文档对象
        return doc;
    }

    public static void main(String[] args) {
        try {
            Connection conn = LvmaGroupPdu.getConnection(DataSourceKey.DEFAULT_KEY);
            LvmaGetGroupPduImg.spider(conn);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //LvmaGroupPdu.spider();
    }

    public static void spider(Connection conn) {

        QueryRunner runner = new QueryRunner();
        String sql = "insert into spider_data (title,content,site_cls,site_name,region,source,other,url,uid) values(?,?,?,?,?,?,?,?,?)";
        //用于记录总页数
        int totalPage = 0;
        //String start = null;//出发城市
        List<Integer> cityNumList = LvmaGroupPdu.getCityNumList();
        for (Integer cityNum : cityNumList) {
            System.out.println("城市代码：" + cityNum);
            Document produDoc = null;
            try {
                produDoc = LvmaGroupPdu.getHtmlDoc(cityNum, null);
            } catch (Exception e) {
                //e.printStackTrace();
                continue;
            }
            Elements pageAEles = null;
            try {
                pageAEles = produDoc.getElementsByClass("pagebox").get(0).getElementsByTag("a");
            } catch (Exception e) {
                //e.printStackTrace();
                continue;
            }
            try {
                String pageTotalNum = pageAEles.get(pageAEles.size() - 2).text();
                System.out.println("当前城市产品页数：" + pageTotalNum);
                totalPage = Integer.valueOf(pageTotalNum);
                if (pageTotalNum != null) {
                    //控制翻页
                    for (int pageNum = 1; pageNum <= totalPage; pageNum++) {
                        Document pageDoc = LvmaGroupPdu.getHtmlDoc(cityNum, pageNum);
                        Elements pduListEles = pageDoc.getElementsByClass("product-item clearfix");
                        //获得当前产品模块
                        int pduListSize = pduListEles.size();
                        System.out.println("产品模块数：" + pduListSize);
                        //遍历每页产品
                        for (int i = 0; i < pduListSize; i++) {
                            //获得当前产品模块
                            Element currentPduEle = pduListEles.get(i);
                            String title = currentPduEle.getElementsByClass("product-title").get(0).getElementsByTag("span").get(0).attr("title");
                            System.out.println("标题：" + title);
                            String pduType = pduListEles.get(i).getElementsByClass("product-label product-label-alpha").text();
                            System.out.println("产品类型：" + pduType);
                            String route = pduListEles.get(i).getElementsByClass("product-city").get(0).text();
                            System.out.println("路线：" + route);
                            String startCity = currentPduEle.getElementsByClass("product-address").text();
                            System.out.println("出发城市：" + startCity);
                            String priceStr = currentPduEle.getElementsByClass("product-price").get(0).getElementsByTag("em").text();
                            Double price = null;
                            try {
                                price = Double.valueOf(priceStr);
                            } catch (NumberFormatException e) {
                                e.printStackTrace();
                            }
                            System.out.println("价格：" + price);
                            Element aEle = currentPduEle.getElementsByClass("product-left").get(0).getElementsByTag("a").get(0);
                            String url = aEle.attr("href");
                            String img = aEle.getElementsByTag("img").get(0).attr("src");
                            System.out.println("img：" + img);
                            System.out.println("url：" + url);
                            String route2 = currentPduEle.getElementsByClass("product-ticket-dropdown").text();
                            System.out.println("路线详细：" + route2);
                            Element pduParamsEle = currentPduEle.getElementsByClass("btn-show-schedule").get(0);
                            String productId = pduParamsEle.attr("productId");
                            System.out.println("产品Id：" + productId);
                            String categoryId = pduParamsEle.attr("categoryId");
                            System.out.println("categoryId" + categoryId);
                            String productType = pduParamsEle.attr("productType");
                            System.out.println("productType" + productType);
                            String startDistrictId = pduParamsEle.attr("startDistrictId");
                            System.out.println("startDistrictId" + startDistrictId);
                            String dataFrom = pduParamsEle.attr("dataFrom");
                            System.out.println("dataFrom" + dataFrom);
                            String dataType = "jsonp";
                            String async = "true";
                            String ajaxUrl = "http://s.lvmama.com/vstRoute/getProdGroupDate.do";
                            Map<String, String> mapAjax = new HashMap<>();
                            mapAjax.put("categoryId", categoryId);
                            mapAjax.put("productType", productType);
                            mapAjax.put("startDistrictId", startDistrictId);
                            mapAjax.put("dataFrom", dataFrom);
                            mapAjax.put("dataType", dataType);
                            mapAjax.put("async", async);
                            mapAjax.put("ajaxUrl", ajaxUrl);
                            mapAjax.put("productId", productId);
                            String mapAjaxStr = JSON.toJSONString(mapAjax);
                            List<Map<String, Object>> maps = new ArrayList<>();
                            Map<String, Object> map = new HashMap<>();
                            map.put("title", title);
                            map.put("url", url);
                            map.put("pduType", pduType);
                            map.put("img", img);
                        /*if(route==null){
                            route=route2;
                        }*/
                            map.put("route", route2);
                            map.put("price", price);
                            map.put("startCity", startCity);
                            maps.add(map);
                            String content = JSON.toJSONString(maps);
                            try {
                                int result = runner.update(conn, sql, title, content, "OTA", "驴妈妈", "云南", "驴妈妈", mapAjaxStr, url, UUIDUtils.getUUID());
                                System.out.println("插入结果：" + result);
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            } catch (Exception e) {
                //e.printStackTrace();
                continue;
            }

        }
    }

    //提供城市代码集合
    public static List<Integer> getCityNumList() {

        List<Integer> cityNumList = new ArrayList<>();
        /*int[] cityNumArr = {13, 9, 14, 31, 256, 56, 69, 155, 258, 324, 322, 233, 308, 123, 291};
        for (int i = 0; i < cityNumArr.length; i++) {
            cityNumList.add(cityNumArr[i]);
        }*/
        for (int i = 0; i <= 999; i++) {
            cityNumList.add(i);
        }
        return cityNumList;
    }

    //获取连接
    public static java.sql.Connection getConnection(String ds_key) throws Exception {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        String url = "" + ResourceUtils.getConfigByName(ds_key + ".url");
        String user = "" + ResourceUtils.getConfigByName(ds_key + ".username");
        String password = "" + ResourceUtils.getConfigByName(ds_key + ".password");
        java.sql.Connection conn = DriverManager.getConnection(url, user, password);
        return conn;
    }
}

