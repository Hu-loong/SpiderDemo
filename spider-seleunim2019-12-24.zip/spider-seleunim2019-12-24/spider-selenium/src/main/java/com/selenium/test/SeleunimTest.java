package com.selenium.test;

import com.selenium.DButils.DataSourceKey;
import com.selenium.DButils.ResourceUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Random;

public class SeleunimTest {
    //public static List<String> urlList = new ArrayList<String>();
    public static final long waitLoadBaseTime = 2000;
    public static final int waitLoadRandomTime = 2000;
    public static final Random random = new Random(System.currentTimeMillis());

    public static WebDriver getDriver(String url_web) {
        try {
            // 等待数据加载的时间
            // 为了防止服务器封锁，这里的时间要模拟人的行为，随机且不能太短
            long waitLoadBaseTime = 2000;
            int waitLoadRandomTime = 2000;
            Random random = new Random(System.currentTimeMillis());
            // 设置 chrome 的路径,直接放在chrome的安装路径即可
            String chrome = "F:\\ChromeDrive\\chromedriver.exe";
            System.setProperty("webdriver.chrome.driver", chrome);
            ChromeOptions options = new ChromeOptions();
            //options.addArguments("--headless");
            // 通过配置参数禁止data;的出现
            /*
             * options.addArguments(
             * "--user-data-dir=C:/Users/Administrator/AppData/Local/Google/Chrome/User Data/Default"
             * );
             */
            /*options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
            // 通过配置参数删除“您使用的是不受支持的命令行标记：--ignore-certificate-errors。稳定性和安全性会有所下降。”提示
            options.addArguments("--start-maximized", "allow-running-insecure-content", "--test-type");
            options.addArguments("--profile-directory=Default");
            // userdata 设置使用chrome的默认参数
            options.addArguments("--user-data-dir=C:/Temp/ChromeProfile");*/
            // 也可以只用自己配置的chrom 设置地址：如下
            // options.addArguments("--user-data-dir=C:/Users/ZHL/AppData/Local/Google/Chrome/User
            // Data");
            // 创建一个 Chrome 的浏览器实例
            WebDriver driver = new ChromeDriver(options);
            // 让浏览器访问微博主页
            driver.get(url_web);
            // 等待页面动态加载完毕
            Thread.sleep(waitLoadBaseTime + random.nextInt(waitLoadRandomTime));
            return driver;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = SeleunimTest.getDriver("http://vacations.lvmama.com/w/tour/100105544?Dcity=322");
        String pageSource = driver.getPageSource();
        Document pageDocs = Jsoup.parse(pageSource);
        Thread.sleep(1000);
        //System.out.println(pageDocs);
        String normalPrice = pageDocs.getElementsByClass("crred").get(0).text();
        System.out.println("一般价格："+normalPrice);
        /*Element element = pageDocs.getElementsByClass("tab-nav-item comment-nav").get(0).getElementsByTag("em").get(0);
        String totalCommStr = element.text().replace("(", "").replace(")", "");
        Integer totalComm = Integer.valueOf(totalCommStr);
        Integer totalPage = (int)Math.ceil(totalComm);
        System.out.println("更多评论Ele："+totalComm);
        System.out.println("总页数："+totalPage);*/
        String aboutComm = pageDocs.getElementsByAttributeValue("data-type", "ABOUT").get(0).text();
        System.out.println(aboutComm);
        Integer totalPageNum = SeleunimTest.getPageNum(aboutComm);
        System.out.println("相关评论页数："+totalPageNum);
        Actions actions=new Actions(driver);
        //点击驴友点评
        actions.moveToElement(driver.findElement(By.cssSelector(".tab-nav-item.comment-nav"))).click().build().perform();
        //另一种点击更多评论
        //actions.moveToElement(driver.findElements(By.id("destorder")).get(0).findElement(By.cssSelector("li[date_id=dianping]"))).click().build().perform();
        String handle = driver.getWindowHandle();
        driver = driver.switchTo().window(handle);
        actions.moveToElement(driver.findElement(By.cssSelector("li[data-type=ABOUT]"))).click().build().perform();
        String handle01 = driver.getWindowHandle();
        driver = driver.switchTo().window(handle01);
        pageDocs = Jsoup.parse(driver.getPageSource());
        //System.out.println(pageDocs);
        SeleunimTest.dealComments(pageDocs);
        for(int nextPage=1;nextPage<=totalPageNum;nextPage++){
            System.out.println("==========第："+nextPage);
            driver = SeleunimTest.clickNextPage(driver);
            pageDocs=Jsoup.parse(driver.getPageSource());
            SeleunimTest.dealComments(pageDocs);
            Thread.sleep(500);
        }


    }

    public static void dealComments(Document document){
        Elements remarkEles = document.getElementsByClass("remark-item");
        Integer remarkSize=remarkEles.size();
        for(int i=0;i<remarkSize;i++){
            Element remarkEle = remarkEles.get(i);
            String comment = remarkEle.getElementsByClass("remark-txt J-applyText").get(0).getElementsByTag("span").get(0).text();
            System.out.println("评论："+comment);
            String commAbout = remarkEle.getElementsByClass("lv-col-9 lv-row cr9").text();
            System.out.println("评论相关："+commAbout);
            String commTime = remarkEle.getElementsByClass("lv-col-1").get(0).text();
            System.out.println("评论时间："+commTime);
            try {
                Connection conn=SeleunimTest.getConnection(DataSourceKey.DEFAULT_KEY);
                String sql ="insert into comments_data (uid,commentinfo) values (?,?)";
                QueryRunner runner=new QueryRunner();
                runner.update(conn,sql,"123456",commTime);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static WebDriver clickNextPage(WebDriver webDriver){
        Actions action =new Actions(webDriver);
        action.moveToElement(webDriver.findElement(By.cssSelector("li[data-type=next]"))).click().build().perform();
        String handle = webDriver.getWindowHandle();
        webDriver = webDriver.switchTo().window(handle);
        return webDriver;
    }

    //相关评论字符串中取数字并向上取整返回页数。
    public static Integer getPageNum(String aboutComm){
        Integer pageNum=null;
        int len = aboutComm.length();
        String totalStr = aboutComm.substring(5, len-1);
        Integer totalComm = Integer.valueOf(totalStr);
        pageNum = (int)Math.ceil((totalComm+0.0)/10);
        return pageNum;
    }

    public static Connection getConnection(String ds_key) throws Exception{
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        String url = ""+ ResourceUtils.getConfigByName(ds_key + ".url");
        String user = ""+ResourceUtils.getConfigByName(ds_key + ".username");
        String password = ""+ResourceUtils.getConfigByName(ds_key + ".password");
        Connection conn = DriverManager.getConnection(url, user, password);
        return conn;
    }

}
