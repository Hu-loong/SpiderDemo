package com.selenium.DButils;

import java.util.ResourceBundle;

/**
 * @author 
 * 2014-08-26
 */
public class ResourceUtils {

	private static final ResourceBundle bundle = ResourceBundle.getBundle("application");
	
	/**
	 * 获取配置文件参数
	 * @param name
	 * @return
	 */
	public static final String getConfigByName(String name) {
		return bundle.containsKey(name)?bundle.getString(name):null;
	}
	
	public static void main(String[] args) {
		System.out.println(ResourceUtils.getConfigByName("test"));
	}

}
