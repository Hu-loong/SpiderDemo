package com.selenium.spider;

import com.alibaba.fastjson.JSON;
import com.selenium.pojo.Comments_data;
import com.selenium.pojo.Spiderdata;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import java.util.*;

public class LvmaSeleumCommon {
    //public static List<String> urlList = new ArrayList<String>();
    public static final long waitLoadBaseTime = 2000;
    public static final int waitLoadRandomTime = 2000;
    public static final Random random = new Random(System.currentTimeMillis());

    public static WebDriver getDriver(String url_web) {
        try {
            // 等待数据加载的时间
            // 为了防止服务器封锁，这里的时间要模拟人的行为，随机且不能太短
//	      long waitLoadBaseTime = 2000;
//	      int waitLoadRandomTime = 2000;
//	      Random random = new Random(System.currentTimeMillis());
            // 设置 chrome 的路径,直接放在chrome的安装路径即可
            String chrome = "F:\\ChromeDrive\\chromedriver.exe";
            System.setProperty("webdriver.chrome.driver", chrome);
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--headless");
            // 通过配置参数禁止data;的出现
            /*
             * options.addArguments(
             * "--user-data-dir=C:/Users/Administrator/AppData/Local/Google/Chrome/User Data/Default"
             * );
             */
            /*options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
            // 通过配置参数删除“您使用的是不受支持的命令行标记：--ignore-certificate-errors。稳定性和安全性会有所下降。”提示
            options.addArguments("--start-maximized", "allow-running-insecure-content", "--test-type");
            options.addArguments("--profile-directory=Default");
            // userdata 设置使用chrome的默认参数
            options.addArguments("--user-data-dir=C:/Temp/ChromeProfile");*/
            // 也可以只用自己配置的chrom 设置地址：如下
            // options.addArguments("--user-data-dir=C:/Users/ZHL/AppData/Local/Google/Chrome/User
            // Data");
            // 创建一个 Chrome 的浏览器实例
            WebDriver driver = new ChromeDriver(options);
            // 让浏览器访问微博主页
            driver.get(url_web);
            // 等待页面动态加载完毕
            Thread.sleep(waitLoadBaseTime + random.nextInt(waitLoadRandomTime));
            return driver;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    public static void getComments(Spiderdata spiderdata) {
        //http://dujia.lvmama.com/package/634175
        WebDriver webDriver = LvmaSeleumCommon.getDriver(spiderdata.getUrl());
        String pageSource = webDriver.getPageSource();
        Document webDoc = Jsoup.parse(pageSource);
        //System.out.println("============="+webDoc);
        System.out.println("-------------------");
        //LvmaSeleumCommon.dealElements(webDoc,spiderdata);
        Document commentDocs = null;
        try {
            commentDocs = LvmaSeleumCommon.clickComments(webDriver);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //System.out.println(commentDocs);
        Integer totalPage = LvmaSeleumCommon.dealComments(commentDocs, spiderdata);
        for (int page = 2; page <= totalPage; page++) {
            Document nextPageComm = LvmaSeleumCommon.nextPageComm(webDriver);
            LvmaSeleumCommon.dealComments(nextPageComm, spiderdata);
            System.out.println("-----总页数：" + page);
        }
        webDriver.close();
    }

    private static void dealElements(Document document, Spiderdata spiderdata) {
        try {
            Elements pduEles = document.getElementsByClass("product_top_r");
            Element pduModel = pduEles.get(0);
            //System.out.println(pduModel);
            Elements titleEles = pduModel.getElementsByTag("h1");
            String title = titleEles.text();
            //System.out.println("标题：" + title);
            Elements pduIdEles = pduModel.getElementsByClass("product_info1");
            String[] pduInfoArr = pduIdEles.text().split(" ");
            StringBuilder sbPduInfo = new StringBuilder();
            for (int i = 1; i < pduInfoArr.length; i++) {
                sbPduInfo.append(pduInfoArr[i]);
                sbPduInfo.append(" ");
                if (i > 20) {
                    break;
                }
            }
            //System.out.println("产品Id：" + sbPduInfo.toString());
            Element pduTotalDay = pduModel.getElementsByClass("xc_tab js_xc_tab").get(0);
            String totalDay = pduTotalDay.getElementsByTag("li").text();
            //System.out.println("TotalDday：" + totalDay);
            String destination = pduModel.getElementsByClass("product_mdd").get(0).getElementsByTag("p").text();
            //System.out.println("Destination：" + destination);
            /*List<Map<String, Object>> maps = new ArrayList<>();
            Map<String, Object> map = new HashMap<>();
            map.put("pduId", sbPduInfo.toString());
            map.put("totalDay", totalDay);
            map.put("Destination",destination);
            maps.add(map);
            spiderdata.setContent(JSON.toJSONString(maps));*/
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //返回带评论的web（点击驴友评论后的web）
    public static Document clickComments(WebDriver webDriver) {
        Document commentsPage = null;
        Actions actions = new Actions(webDriver);
        try {

            //注意下面的方法是通过下标获取的，可能会不通用，自己想着改改；
            actions.moveToElement(webDriver.findElements(By.id("destorder")).get(0).findElement(By.cssSelector("li[date_id=dianping]"))).click().build().perform();
            Thread.sleep(100);
            String pageSourceComments = webDriver.getPageSource();
            commentsPage = Jsoup.parse(pageSourceComments);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (IndexOutOfBoundsException e) {
            actions.moveToElement(webDriver.findElement(By.cssSelector("div[class=tab-nav-item comment-nav]"))).click().build().perform();
            String pageSourceComments = webDriver.getPageSource();
            commentsPage = Jsoup.parse(pageSourceComments);
            return commentsPage;
        } catch (Exception e) {
            actions.moveToElement(webDriver.findElements(By.id("destorder")).get(0).findElement(By.cssSelector("li[date_id=comments]"))).click().build().perform();
            String pageSourceComments = webDriver.getPageSource();
            commentsPage = Jsoup.parse(pageSourceComments);
            return commentsPage;
        }
        return commentsPage;
    }

    public static Integer dealComments(Document document, Spiderdata spiderdata) {
        try {
            Elements commentEles = document.getElementsByClass("comment-li");
            //System.out.println(commentEles);
            List<String> commList = new ArrayList<>();
            if (commentEles.size() > 3) {
                for (int i = 0; i < commentEles.size(); i++) {
                    String comment = commentEles.get(i).getElementsByClass("ufeed-content").text();
                    commList.add("【" + (i + 1) + "】" + comment + "[commInfo]");
                    String commInfo = commentEles.get(i).getElementsByClass("com-userinfo").text();
                    String commTime = commentEles.get(i).getElementsByClass("com-userinfo").get(0).getElementsByTag("p").get(0).getElementsByTag("em").text();
                    commList.add(commInfo);
                    commList.add(" Time " + commTime + "#*#*#");
                    Comments_data comments_data = new Comments_data();
                    comments_data.setUid(spiderdata.getUid());
                    List<Map<String, Object>> maps = new ArrayList<>();
                    Map<String, Object> map = new HashMap<>();
                    map.put("comment", comment);
                    map.put("time", commTime);
                    map.put("other", commInfo);
                    maps.add(map);
                    comments_data.setCommeninfo(JSON.toJSONString(maps));
                    System.out.println(comments_data);
                }
            }
        } catch (Exception e) {
            Elements commentEles = document.getElementsByClass("remark-item");
            //System.out.println(commentEles);
            List<String> commList = new ArrayList<>();
            if (commentEles.size() > 3) {
                for (int i = 0; i < commentEles.size(); i++) {
                    String comment = commentEles.get(i).getElementsByClass("remark-body").get(0).child(0).text();

                    Comments_data comments_data = new Comments_data();
                    comments_data.setUid(spiderdata.getUid());
                    List<Map<String, Object>> maps = new ArrayList<>();
                    Map<String, Object> map = new HashMap<>();
                    map.put("comment", comment);
                    maps.add(map);
                    comments_data.setCommeninfo(JSON.toJSONString(maps));
                    System.out.println(comments_data);
                }
            }
        }
        //System.out.println("打印评论："+commList.toString());
        Elements aEles = document.getElementsByClass("pagebox").get(0).getElementsByTag("a");
        int aSize = aEles.size();
        String total = aEles.get(aSize - 2).text();
        Integer totalNum = Integer.valueOf(total);
        System.out.println("总页数：" + total);
        if (totalNum > 250) {
            totalNum = 0;
        }
        return totalNum;

    }

    public static Document nextPageComm(WebDriver webDriver) {
        Actions nextPageAction = new Actions(webDriver);
        nextPageAction.moveToElement(webDriver.findElements(By.className("nextpage")).get(0)).click().build().perform();
        Document nextPComm = null;
        nextPComm = Jsoup.parse(webDriver.getPageSource());
        return nextPComm;
    }


}
