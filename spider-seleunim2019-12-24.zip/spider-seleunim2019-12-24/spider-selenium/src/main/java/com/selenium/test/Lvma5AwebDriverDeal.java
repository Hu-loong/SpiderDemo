package com.selenium.test;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.WebDriver;

//驴妈妈5a景区页面处理
public class Lvma5AwebDriverDeal {
    public static void dealWeDriver(WebDriver driver){
        String pageSource = driver.getPageSource();
        Document pageDoc = Jsoup.parse(pageSource);
        //System.out.println(pageDoc);
        Document tagH2 = Jsoup.parse(pageDoc.getElementsByTag("h2").toString());
        String title = tagH2.getElementsByClass("title").text();
        System.out.println("景区名："+title);
        String type = pageDoc.getElementsByClass("vcomon-icon").text();
        System.out.println("景区类型："+type);
        String price = pageDoc.getElementsByClass("big-price").text();
        System.out.println("价格："+price);
        String info = pageDoc.getElementsByClass("vtop-address-box vtop-height clearfix").text();
        System.out.println("景区信息："+info);
        Elements commentLis = pageDoc.getElementsByClass("comment-li");
        System.out.println(commentLis.size());
        for (int i=0;i<commentLis.size();i++){
            Element commModel = commentLis.get(i);
            //commModel.getElementsByClass("");

        }

    }
}
