package com.selenium.dataOperate;

import com.selenium.DButils.DataSourceKey;
import com.selenium.DButils.ResourceUtils;
import com.selenium.dbOperate.DeleteSameRecord;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class SetCityId {

    public static void main(String[] args) {
        Connection conn = null;
        try {
            conn = DeleteSameRecord.getConnection(DataSourceKey.DEFAULT_KEY);
        } catch (Exception e) {
            e.printStackTrace();
        }
        QueryRunner runner = new QueryRunner();
        List<Map<String, Object>> listMap = null;
        try {
            listMap = runner.query(conn, "select * from yq_travel_route ", new MapListHandler());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        for (Map<String, Object> map : listMap) {
            String cityName = (String) map.get("cityName");
            Integer route_id = (Integer) map.get("route_id");
            System.out.println(cityName);
            try {
                List<Map<String, Object>> cityListMap = runner.query(conn, "select city_id from cities where city like '" + cityName + "%' limit 1", new MapListHandler());
                if (cityListMap.size() > 0) {
                    String city_idStr = (String) cityListMap.get(0).get("city_id");
                    Integer city_id = Integer.valueOf(city_idStr);
                    System.out.println(city_id);
                    int update = runner.update(conn, "update yq_travel_route set departure_city_id = ? where route_id= ? ", city_id, route_id);
                    System.out.println("更新结果：" + update);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }

    }

    //获取连接
    public static java.sql.Connection getConnection(String ds_key) throws Exception {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        String url = "" + ResourceUtils.getConfigByName(ds_key + ".url");
        String user = "" + ResourceUtils.getConfigByName(ds_key + ".username");
        String password = "" + ResourceUtils.getConfigByName(ds_key + ".password");
        java.sql.Connection conn = DriverManager.getConnection(url, user, password);
        return conn;
    }
}
