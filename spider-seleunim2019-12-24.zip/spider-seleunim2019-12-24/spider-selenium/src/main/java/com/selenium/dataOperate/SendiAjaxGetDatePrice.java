package com.selenium.dataOperate;

import com.alibaba.fastjson.JSON;
import com.selenium.DButils.DataSourceKey;
import com.selenium.DButils.ResourceUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class SendiAjaxGetDatePrice {
    public static Document getHtmlDoc(String action, String productId, String categoryId, String startDistrictId, String productType, String dataFrom) {
        CloseableHttpClient httpclient = HttpClients.createDefault(); // 创建httpclient实例
        String urlIndex = action + "?" + "productId=" + productId + "&" + "categoryId=" + categoryId + "&" + "startDistrictId=" + startDistrictId + "&" + "productType=" + productType + "&" + "dataFrom=" + dataFrom;
        System.out.println("合成的Url:" + urlIndex);
        HttpGet httpget = new HttpGet(urlIndex); // 创建httpget实例
        CloseableHttpResponse response = null; // 执行get请求
        String content = null;
        try {
            response = httpclient.execute(httpget);
            HttpEntity entity = response.getEntity(); // 获取返回实体
            content = EntityUtils.toString(entity, "gbk");
            response.close(); // 关闭流和释放系统资源
        } catch (IOException e) {
            e.printStackTrace();
        }
        Document doc = Jsoup.parse(content); // 解析网页 得到文档对象
        return doc;
    }

    public static void main(String[] args) {
        Connection conn = null;
        try {
            conn = SendiAjaxGetDatePrice.getConnection(DataSourceKey.DEFAULT_KEY);
        } catch (Exception e) {
            e.printStackTrace();
        }
        QueryRunner runner = new QueryRunner();
        List<Map<String, Object>> mapListData = null;
        try {
            mapListData = runner.query(conn, "select id,other from spider_data_local", new MapListHandler());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        for (Map<String, Object> mapData : mapListData) {
            Integer id = (Integer) mapData.get("id");
            String otherStr = (String) mapData.get("other");
            Map<String, Object> otherMap = (Map<String, Object>) JSON.parse(otherStr);
            System.out.println(id + "---" + otherMap);
            String ajaxUrl = (String) otherMap.get("ajaxUrl");
            String productId = (String) otherMap.get("productId");
            String categoryId = (String) otherMap.get("categoryId");
            String startDistrictId = (String) otherMap.get("startDistrictId");
            String productType = (String) otherMap.get("productType");
            String dataFrom = (String) otherMap.get("dataFrom");
            Document htmlDoc = null;
            try {
                htmlDoc = SendiAjaxGetDatePrice.getHtmlDoc(ajaxUrl, productId, categoryId, startDistrictId, productType, dataFrom);
            } catch (Exception e) {
                //e.printStackTrace();
                continue;
            }
            //System.out.println(htmlDoc);
            String body = htmlDoc.getElementsByTag("body").text();
            //System.out.println(body);
            String data = body.substring(4);
            String jsonData = data.substring(1, data.length() - 1);
            //System.out.println(jsonData);
            Map<String, Object> map = (Map<String, Object>) JSON.parse(jsonData);
            //System.out.println(map);
            List<Map<String, Object>> listMap = (List<Map<String, Object>>) map.get("data");
            /*for (Map<String, Object> stringObjectMap : listMap) {
                System.out.println(stringObjectMap);
            }*/
            String datePrice = JSON.toJSONString(listMap);
            try {
                int update = runner.update(conn, "update spider_data_local set datePrice=? where id = ?", datePrice, id);
                System.out.println("id为：" + id + "的更新结果：" + update);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    //获取连接
    public static java.sql.Connection getConnection(String ds_key) throws Exception {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        String url = "" + ResourceUtils.getConfigByName(ds_key + ".url");
        String user = "" + ResourceUtils.getConfigByName(ds_key + ".username");
        String password = "" + ResourceUtils.getConfigByName(ds_key + ".password");
        java.sql.Connection conn = DriverManager.getConnection(url, user, password);
        return conn;
    }
}
