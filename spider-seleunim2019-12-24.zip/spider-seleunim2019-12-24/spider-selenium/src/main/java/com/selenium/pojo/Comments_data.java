package com.selenium.pojo;

public class Comments_data {
    private Integer id;
    private String uid;
    private String commeninfo;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getCommeninfo() {
        return commeninfo;
    }

    public void setCommeninfo(String commeninfo) {
        this.commeninfo = commeninfo;
    }

    @Override
    public String toString() {
        return "Comments_data{" +
                "id=" + id +
                ", uid='" + uid + '\'' +
                ", commeninfo='" + commeninfo + '\'' +
                '}';
    }
}
