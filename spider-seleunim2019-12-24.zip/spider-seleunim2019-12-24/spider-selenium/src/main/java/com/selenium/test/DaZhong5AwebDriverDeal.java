package com.selenium.test;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

import java.util.HashSet;
import java.util.Set;

//驴妈妈5a景区页面处理
public class DaZhong5AwebDriverDeal {
    public static void dealWeDriver(WebDriver driver) throws InterruptedException {
        driver.manage().getCookies().size();
        //Cookie cookie=new Cookie();
        String pageSource = driver.getPageSource();
        Document pageDoc = Jsoup.parse(pageSource);
        //System.out.println("-------------"+pageDoc);
        //System.out.println("-------------");
        WebElement yodaBox = driver.findElement(By.id("yodaBox"));
        Actions action=new Actions(driver);
        //ActionChains(driver).click_and_hold(on_element=yodaBox).perform()
        //获取滑动块的location
        Point location=yodaBox.getLocation();
        //滑动滑动块
        action.dragAndDropBy(yodaBox, location.x+99,location.y).perform();
        Thread.sleep(6000);
        String newPageSource = driver.getPageSource();
        //更新cookie
        Document newPageDoc = Jsoup.parse(newPageSource);
        System.out.println(newPageDoc);
    }
}
