package com.selenium.dataOperate;

import com.alibaba.fastjson.JSON;
import com.selenium.DButils.DataSourceKey;
import com.selenium.DButils.ResourceUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class FullRoutePriceTable {

    public static void main(String[] args) {
        Connection conn=null;
        try {
            conn = FullRoutePriceTable.getConnection(DataSourceKey.DEFAULT_KEY);
        } catch (Exception e) {
            e.printStackTrace();
        }
        QueryRunner runner=new QueryRunner();
        try {
            List<Map<String, Object>> listMapTraRoute = runner.query(conn, "select route_id,datePrice from yq_travel_route ", new MapListHandler());
            System.out.println("数量："+listMapTraRoute.size());
            System.out.println("----------------------------------------------");
            for (Map<String, Object> mapTraRoute : listMapTraRoute) {
                Integer route_id = (Integer) mapTraRoute.get("route_id");
                String datePriceStr = (String) mapTraRoute.get("datePrice");
                //System.out.println(datePriceStr);
                List<Map<String,Object>> datePriceListMap = (List<Map<String, Object>>) JSON.parse(datePriceStr);
                //System.out.println(datePriceListMap);
                for (Map<String, Object> datePriceMap : datePriceListMap) {
                    String date = (String) datePriceMap.get("date");
                    System.out.println(date);
                    Integer lowestSaledPrice = (Integer) datePriceMap.get("lowestSaledPrice");
                    System.out.println(lowestSaledPrice);
                    Integer inventory = (Integer) datePriceMap.get("inventory");
                    System.out.println("库存："+inventory);
                    int update = runner.update(conn, "insert into yq_route_price (route_id,departure_date,price,inventory) values (?,?,?,?)", route_id, date, lowestSaledPrice, inventory);
                    System.out.println("插入结果："+update);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    //获取连接
    public static java.sql.Connection getConnection(String ds_key) throws Exception {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        String url = "" + ResourceUtils.getConfigByName(ds_key + ".url");
        String user = "" + ResourceUtils.getConfigByName(ds_key + ".username");
        String password = "" + ResourceUtils.getConfigByName(ds_key + ".password");
        java.sql.Connection conn = DriverManager.getConnection(url, user, password);
        return conn;
    }
}
