package com.selenium.pojo;

import java.util.Date;

public class Spiderdata {
    private Integer id; //int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
    private String title; //varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '标题',
    private String content; //text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '正文',

    private Date actiontime; //datetime(0) DEFAULT NULL COMMENT '时间',

    private String author; //varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '作者',
    private String site_cls; //varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '站点分类',
    private String site_name; //varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '站点名称',
    private String region; //varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '区域',
    private String status; //varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '正负面,1正面，0负面',
    private String source; //varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '来源',
    private String other; //text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '其他补充信息',
    private String url; //varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '详细地址',
    private String uid; //varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '序列ID',


    public Date getActiontime() {
        return actiontime;
    }

    public void setActiontime(Date actiontime) {
        this.actiontime = actiontime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getSite_cls() {
        return site_cls;
    }

    public void setSite_cls(String site_cls) {
        this.site_cls = site_cls;
    }

    public String getSite_name() {
        return site_name;
    }

    public void setSite_name(String site_name) {
        this.site_name = site_name;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    @Override
    public String toString() {
        return "Spiderdata{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", actiontime=" + actiontime +
                ", author='" + author + '\'' +
                ", site_cls='" + site_cls + '\'' +
                ", site_name='" + site_name + '\'' +
                ", region='" + region + '\'' +
                ", status='" + status + '\'' +
                ", source='" + source + '\'' +
                ", other='" + other + '\'' +
                ", url='" + url + '\'' +
                ", uid='" + uid + '\'' +
                '}';
    }
}
