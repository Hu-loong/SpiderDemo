package com.selenium.dataOperate;

import com.alibaba.fastjson.JSON;
import com.selenium.DButils.DataSourceKey;
import com.selenium.DButils.ResourceUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class PutPduIdIntoOther {


    public static void main(String[] args) {
        Connection conn = null;
        try {
            conn = PutPduIdIntoOther.getConnection(DataSourceKey.DEFAULT_KEY);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String querySql = "select id,content,datePrice from spider_data_local";
        QueryRunner runner = new QueryRunner();
        List<Map<String, Object>> content = null;
        try {
            content = runner.query(conn, querySql, new MapListHandler());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        List<Map<String, Object>> content01;
        //System.out.println("---"+content);
        for (Map<String, Object> map : content) {
            String content1 = (String) map.get("content");
            //System.out.println(content1);

            String datePriceStr = (String) map.get("datePrice");
            if(datePriceStr=="[]"){
                datePriceStr=null;
            }
            content01 = (List<Map<String, Object>>) JSON.parse(content1);
            String pduId = (String) content01.get(0).get("pduId");
            System.out.println(pduId);
            String ex_route_id = null;
            try {
                ex_route_id = pduId.substring(6);
            } catch (Exception e) {
                //e.printStackTrace();
                ex_route_id = null;
            }
            System.out.println("s商品Id：" + ex_route_id);
            String route = (String) content01.get(0).get("route");
            System.out.println("路线：" + route);
            String img = (String) content01.get(0).get("img");
            System.out.println("图片：" + img);
            Map<String, Object> mapContent = content01.get(0);
            String vendor1 = (String) mapContent.get("agency");
            String title = (String) mapContent.get("title");
            String vendor = null;
            try {
                vendor = vendor1.substring(4);
            } catch (Exception e) {

            }
            System.out.println("供应商：" + vendor);
            String departure_city_id = (String) mapContent.get("startCity");
            String cityName = departure_city_id.substring(0, 2);
            System.out.println("城市" + cityName);
            String tDay = (String) mapContent.get("tDay");
            Integer num_day = null;
            try {
                num_day = Integer.valueOf(tDay.substring(0, 1));
            } catch (Exception e) {
                //e.printStackTrace();
            }
            System.out.println("总天数：" + num_day);
            Integer source_id = 6;
            String url = (String) mapContent.get("url");
            System.out.println("url：" + url);
            try {
                int update = runner.update(conn, "insert into yq_travel_route (title,image,vendor,num_day,source_id,source_url,ex_route_id,route,cityName,datePrice) values (?,?,?,?,?,?,?,?,?,?)", title, img, vendor, num_day, source_id, url, ex_route_id, route,cityName,datePriceStr);
                System.out.println("插入结果：" + update);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    //获取连接
    public static java.sql.Connection getConnection(String ds_key) throws Exception {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        String url = "" + ResourceUtils.getConfigByName(ds_key + ".url");
        String user = "" + ResourceUtils.getConfigByName(ds_key + ".username");
        String password = "" + ResourceUtils.getConfigByName(ds_key + ".password");
        java.sql.Connection conn = DriverManager.getConnection(url, user, password);
        return conn;
    }
}
