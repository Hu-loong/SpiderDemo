package com.selenium.spider;

import com.selenium.DButils.DataSourceKey;
import com.selenium.DButils.QueryRunnerHandler;
import com.selenium.DButils.ResourceUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

public class LvmamaPdu {

    public static Document getHtmlDoc(int cityNum, int pageNum) {

        CloseableHttpClient httpclient = HttpClients.createDefault(); // 创建httpclient实例
        String preUrl = "http://s.lvmama.com/route/H";
        String centerUrl = "K440100P";
        String sufferUrl = "?keyword=%E4%BA%91%E5%8D%97&k=0&losc=332207&ict=i#list";
        String urlIndex = preUrl + pageNum + centerUrl + cityNum + sufferUrl;
        System.out.println("合成的Url:" + urlIndex);
        HttpGet httpget = new HttpGet(urlIndex); // 创建httpget实例
        CloseableHttpResponse response = null; // 执行get请求
        String content = null;
        try {
            response = httpclient.execute(httpget);
            HttpEntity entity = response.getEntity(); // 获取返回实体
            content = EntityUtils.toString(entity, "gbk");
            response.close(); // 关闭流和释放系统资源
        } catch (IOException e) {
            e.printStackTrace();
        }
        Document doc = Jsoup.parse(content); // 解析网页 得到文档对象
        return doc;
    }
    public void spider() throws Exception {
        Connection conn = LvmamaPdu.getConnection(DataSourceKey.DEFAULT_KEY);
        QueryRunner runner =new QueryRunner();
        int h = 0;
        String start = null;
        for (int k = 1; k <= 389; k++) {
            for (int i = 1; i <= 10; i++) {
                Document docx = getHtmlDoc(i, k);
                Elements productModels = docx.getElementsByClass("product-item clearfix");
                Elements cityEles = docx.getElementsByClass("btn_city js_searchbox");
                if (cityEles.size() > 0) {
                    Element cityEle = cityEles.get(0);
                    start = cityEle.child(0).text();
                }
                //每页有30条数据
                System.out.println("本页最大产品数" + productModels.size());
                //设置本页产品最大循环遍历次数
                h = productModels.size();
                for (int j = 0; j < h; j++) {
                    //Lvmapdu lvPdu = new Lvmapdu();
                    try {
                        Element productModel = productModels.get(j); // 获取第个元素j
                        Elements elementsByClass = productModel.getElementsByClass("product-left");
                        Element hrefEle = elementsByClass.get(0);
                        Elements cityEle = hrefEle.getElementsByClass("product-address");
                        //System.out.println("----" + cityEle);
                        String title = productModel.text(); // 返回元素的文本
                        Document hrefDoc = Jsoup.parse(hrefEle.toString());
                        Elements tagA = hrefDoc.getElementsByTag("a");
                        String href = tagA.attr("href");
                        String city = cityEle.html();
                        Elements totalTimeEles = productModel.getElementsByClass("product-label-bottom product-label-alpha");
                        String totalTimeStr = totalTimeEles.text();
                        //System.out.println("时长：" + totalTimeStr);
                        Elements hotalEles = docx.getElementsByClass("product-dropdown");
                        String hotal = null;
                        if (hotalEles.size() > 2) {
                            Element hotalEle = hotalEles.get(2);
                            hotal = hotalEle.ownText();
                            //System.out.println("酒店：" + hotal);
                        }
                        //System.out.println("酒店下标未越界");
                        Elements lowPriceEles = docx.getElementsByClass("product-price");
                        String lowPrice = null;
                        if (lowPriceEles.size() > 4) {
                            Element lowPriceEle = lowPriceEles.get(4);
                            lowPrice = lowPriceEle.text();
                            if (lowPrice != null) {
                                // System.out.println("最低价：" + lowPrice);
                            }
                        }
                        //System.out.println("最低价下标未越界");
                        Elements startTimeElex = docx.getElementsByClass("product-details clearfix");
                        Element startTimeEles = startTimeElex.get(1);
                        Document stimeDoc = Jsoup.parse(startTimeEles.toString());
                        Elements stimeEles = stimeDoc.getElementsByTag("em");
                        String stime = stimeEles.text();

                    } catch (IndexOutOfBoundsException e) {
                        System.out.println("下标越界！");
                    }
                }
            }
        }
    }



    //获取连接
    public static Connection getConnection(String ds_key) throws Exception{
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        String url = ""+ ResourceUtils.getConfigByName(ds_key + ".url");
        String user = ""+ResourceUtils.getConfigByName(ds_key + ".username");
        String password = ""+ResourceUtils.getConfigByName(ds_key + ".password");
        Connection conn = DriverManager.getConnection(url, user, password);
        return conn;
    }

}