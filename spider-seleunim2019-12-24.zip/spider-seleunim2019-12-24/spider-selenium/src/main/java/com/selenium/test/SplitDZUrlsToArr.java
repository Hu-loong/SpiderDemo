package com.selenium.test;

import java.util.ArrayList;
import java.util.List;

public class SplitDZUrlsToArr {

    public static List<String> getUrlList() {
        String urls = "http://www.dianping.com/shop/9317712\n" +
                "http://www.dianping.com/shop/2368702\n" +
                "http://www.dianping.com/shop/2625724\n" +
                "http://www.dianping.com/shop/2050870\n" +
                "http://www.dianping.com/shop/4196395\n" +
                "http://www.dianping.com/shop/2434921\n" +
                "http://www.dianping.com/shop/44895454\n" +
                "http://www.dianping.com/shop/1653562\n" +
                "http://www.dianping.com/shop/2853403\n" +
                "http://www.dianping.com/shop/2015566\n" +
                "http://www.dianping.com/shop/58565926\n" +
                "http://www.dianping.com/shop/6114157\n" +
                "http://www.dianping.com/shop/16314574\n" +
                "http://www.dianping.com/shop/3472708\n" +
                "http://www.dianping.com/shop/16690998\n" +
                "http://www.dianping.com/shop/1996387\n" +
                "http://www.dianping.com/shop/6112732\n" +
                "http://www.dianping.com/shop/5286325\n" +
                "http://www.dianping.com/shop/38312224\n" +
                "\n" +
                "http://www.dianping.com/shop/13022753\n" +
                "\n" +
                "http://www.dianping.com/shop/9316231\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/2252206\n" +
                "http://www.dianping.com/shop/5260785\n" +
                "http://www.dianping.com/shop/5542907\n" +
                "http://www.dianping.com/shop/45452277\n" +
                "http://www.dianping.com/shop/2873629\n" +
                "http://www.dianping.com/shop/23164505\n" +
                "http://www.dianping.com/shop/4529991\n" +
                "http://www.dianping.com/shop/9313444\n" +
                "\n" +
                "http://www.dianping.com/shop/12443510\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/5418728\n" +
                "http://www.dianping.com/shop/23454624\n" +
                "http://www.dianping.com/shop/5447534\n" +
                "http://www.dianping.com/shop/23349912\n" +
                "http://www.dianping.com/shop/5331314\n" +
                "http://www.dianping.com/shop/17635646\n" +
                "http://www.dianping.com/shop/5724047\n" +
                "http://www.dianping.com/shop/27163899\n" +
                "http://www.dianping.com/shop/9317208\n" +
                "http://www.dianping.com/shop/20830758\n" +
                "\n" +
                "http://www.dianping.com/shop/5709422\n" +
                "\n" +
                "http://www.dianping.com/shop/3136501\n" +
                "http://www.dianping.com/shop/28612321\n" +
                "http://www.dianping.com/shop/2991190\n" +
                "http://www.dianping.com/shop/3050281\n" +
                "http://www.dianping.com/shop/98577409\n" +
                "http://www.dianping.com/shop/27269022\n" +
                "http://www.dianping.com/shop/8694572\n" +
                "http://www.dianping.com/shop/12904954\n" +
                "http://www.dianping.com/shop/5387125\n" +
                "http://www.dianping.com/shop/35994114\n" +
                "http://www.dianping.com/shop/8694598\n" +
                "http://www.dianping.com/shop/17928589\n" +
                "http://www.dianping.com/shop/5451019\n" +
                "http://www.dianping.com/shop/5450957\n" +
                "http://www.dianping.com/shop/2638696\n" +
                "\n" +
                "http://www.dianping.com/shop/11915029\n" +
                "http://www.dianping.com/shop/6112478\n" +
                "http://www.dianping.com/shop/2626402\n" +
                "http://www.dianping.com/shop/9313513\n" +
                "http://www.dianping.com/shop/37787086\n" +
                "http://www.dianping.com/shop/2395495\n" +
                "http://www.dianping.com/shop/2746723\n" +
                "http://www.dianping.com/shop/2673253\n" +
                "http://www.dianping.com/shop/8927665\n" +
                "http://www.dianping.com/shop/3589849\n" +
                "http://www.dianping.com/shop/3020764\n" +
                "http://www.dianping.com/shop/8989275\n" +
                "http://www.dianping.com/shop/3044038\n" +
                "http://www.dianping.com/shop/5712463\n" +
                "http://www.dianping.com/shop/45190351\n" +
                "http://www.dianping.com/shop/111040621\n" +
                "http://www.dianping.com/shop/21920755\n" +
                "\n" +
                "http://www.dianping.com/shop/3440977\n" +
                "http://www.dianping.com/shop/90496700\n" +
                "http://www.dianping.com/shop/6114123\n" +
                "http://www.dianping.com/shop/90496938\n" +
                "http://www.dianping.com/shop/23947118\n" +
                "http://www.dianping.com/shop/66804464\n" +
                "http://www.dianping.com/shop/66779777\n" +
                "http://www.dianping.com/shop/56675819\n" +
                "http://www.dianping.com/shop/1653583\n" +
                "http://www.dianping.com/shop/1653547\n" +
                "\n" +
                "http://www.dianping.com/shop/13342684\n" +
                "http://www.dianping.com/shop/21925440\n" +
                "http://www.dianping.com/shop/9316218\n" +
                "\n" +
                "http://www.dianping.com/shop/9317983\n" +
                "http://www.dianping.com/shop/79429873\n" +
                "http://www.dianping.com/shop/44219299\n" +
                "\n" +
                "http://www.dianping.com/shop/90498829\n" +
                "http://www.dianping.com/shop/12236147\n" +
                "http://www.dianping.com/shop/12233382\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/4658455\n" +
                "http://www.dianping.com/shop/12446503\n" +
                "\n" +
                "http://www.dianping.com/shop/12448413\n" +
                "http://www.dianping.com/shop/57806881\n" +
                "http://www.dianping.com/shop/15028562\n" +
                "http://www.dianping.com/shop/12446503\n" +
                "http://www.dianping.com/shop/105897349\n" +
                "\n" +
                "http://www.dianping.com/shop/90532668\n" +
                "http://www.dianping.com/shop/58866930\n" +
                "\n" +
                "http://www.dianping.com/shop/9316016\n" +
                "http://www.dianping.com/shop/13300485\n" +
                "http://www.dianping.com/shop/1385907842\n" +
                "http://www.dianping.com/shop/13300129\n" +
                "http://www.dianping.com/shop/112206609\n" +
                "http://www.dianping.com/shop/3018253\n" +
                "http://www.dianping.com/shop/6113276\n" +
                "http://www.dianping.com/shop/4105898\n" +
                "http://www.dianping.com/shop/4105842\n" +
                "http://www.dianping.com/shop/11871934\n" +
                "http://www.dianping.com/shop/58845931\n" +
                "http://www.dianping.com/shop/6112458\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/9032568\n" +
                "http://www.dianping.com/shop/58566688\n" +
                "\n" +
                "http://www.dianping.com/shop/59160221\n" +
                "http://www.dianping.com/shop/2846533\n" +
                "http://www.dianping.com/shop/6112748\n" +
                "http://www.dianping.com/shop/67338423\n" +
                "\n" +
                "http://www.dianping.com/shop/9315308\n" +
                "http://www.dianping.com/shop/9315314\n" +
                "http://www.dianping.com/shop/96869879\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/6225738\n" +
                "\n" +
                "http://www.dianping.com/shop/57166629\n" +
                "http://www.dianping.com/shop/6114396\n" +
                "http://www.dianping.com/shop/14023761\n" +
                "http://www.dianping.com/shop/13399523\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/14211645\n" +
                "http://www.dianping.com/shop/44015952\n" +
                "http://www.dianping.com/shop/13022196\n" +
                "http://www.dianping.com/shop/112304136\n" +
                "http://www.dianping.com/shop/13009787\n" +
                "http://www.dianping.com/shop/77841721\n" +
                "http://www.dianping.com/shop/13011971\n" +
                "http://www.dianping.com/shop/13012478\n" +
                "http://www.dianping.com/shop/58075184\n" +
                "http://www.dianping.com/shop/9738771\n" +
                "http://www.dianping.com/shop/5326569\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/56740941\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/3687850\n" +
                "http://www.dianping.com/shop/50664053\n" +
                "http://www.dianping.com/shop/11833476\n" +
                "\n" +
                "http://www.dianping.com/shop/8885527\n" +
                "http://www.dianping.com/shop/98359449\n" +
                "http://www.dianping.com/shop/14988424\n" +
                "http://www.dianping.com/shop/112228473\n" +
                "\n" +
                "http://www.dianping.com/shop/12862355\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/9317355\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/19511004\n" +
                "http://www.dianping.com/shop/11871069\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/2706874\n" +
                "http://www.dianping.com/shop/129048563\n" +
                "http://www.dianping.com/shop/2434975\n" +
                "http://www.dianping.com/shop/58564076\n" +
                "http://www.dianping.com/shop/6114517\n" +
                "http://www.dianping.com/shop/6112530\n" +
                "\n" +
                "http://www.dianping.com/shop/6113390\n" +
                "http://www.dianping.com/shop/6112539\n" +
                "http://www.dianping.com/shop/67261118\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/49267842\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/12213029\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.dianping.com/shop/77378525\n" +
                "http://www.dianping.com/shop/12158893\n" +
                "\n" +
                "http://www.dianping.com/shop/43926840\n" +
                "\n" +
                "http://www.dianping.com/shop/9317353\n" +
                "\n" +
                "http://www.dianping.com/shop/12212334";

        String[] urlArr = urls.split("\\n");
        List<String> list = new ArrayList<>();
        for (String s : urlArr) {
            //System.out.println(s.length());
            if (s.length() != 0) {
                list.add(s);
            }
        }
        return list;
    }
    /*public static void main(String[] args) {
        List<String> urlList = SplitStringToArr.getUrlList();
        for (String s : urlList) {
            System.out.println(s);
        }
    }*/
}

