package com.selenium.DButils;

public class DataSourceKey {
	
	public static final String DEFAULT_KEY = "default";

}
