package com.selenium.test;

import java.util.ArrayList;
import java.util.List;

public class SplitStringToArr {
    public static List<String> getUrlList() {
        String urls="http://www.lvmama.com/lvyou/poi/sight-101204.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103027.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104777.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-100974.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108156.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-107960.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101141.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101099.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101086.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101091.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108499.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104951.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104313.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-178381.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-11318538.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104123.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-159452.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101300.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101100.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101110.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-158664.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-158700.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-161438.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108684.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-159238.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101257.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-174229.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-159813.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-162246.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108405.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-107970.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103710.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103693.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108461.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103717.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101289.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-106790.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104298.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104198.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104034.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108254.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-161480.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-10673400.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104033.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-159351.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-174458.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104047.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-100232.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-100231.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101105.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-102103.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-107969.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-107926.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-100305.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-174456.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104962.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101298.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-160169.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104292.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104360.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104216.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104228.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104231.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104348.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101049.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101249.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-100970.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101120.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104051.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104072.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-157456.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-100064.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104042.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-101156.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104028.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104152.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-173678.html\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104103.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-159605.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-173634.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-177821.html\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104073.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104105.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104001.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104012.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103995.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-174594.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108668.html\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108501.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104187.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108728.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104338.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108699.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103682.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108429.html\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-10653725.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104242.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-159083.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108504.html\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108476.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104347.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-159236.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-159342.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-159365.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104263.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-174253.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103807.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-10673210.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-105773.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-10657873.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108858.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108791.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104032.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108393.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-160166.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108874.html\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104110.html\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103768.html\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-159726.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-177553.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103683.html\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-160753.html\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104281.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104036.html\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108563.html\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104043.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108905.html\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-105760.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108907.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104157.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104045.html\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-158699.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104337.html\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-108830.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104029.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103884.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-171313.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104028.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104164.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-161368.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104055.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-171945.html\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-177397.html\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104046.html\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-104059.html\n" +
                "\n" +
                "\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103829.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-103845.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-160888.html\n" +
                "http://www.lvmama.com/lvyou/poi/sight-107752.html";


        String[] urlArr = urls.split("\\n");
        List<String> list=new ArrayList<>();
        for (String s : urlArr) {
            //System.out.println(s.length());
            if(s.length()!=0){
                list.add(s);
            }
        }
        return list;
    }

    /*public static void main(String[] args) {
        List<String> urlList = SplitStringToArr.getUrlList();
        for (String s : urlList) {
            System.out.println(s);
        }
    }*/
}
