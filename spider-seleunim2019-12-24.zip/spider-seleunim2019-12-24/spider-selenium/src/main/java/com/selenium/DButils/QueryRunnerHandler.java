package com.selenium.DButils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;
import org.apache.commons.dbutils.QueryRunner;

public abstract class QueryRunnerHandler{
	
	private static final String defaultDsKey = DataSourceKey.DEFAULT_KEY;
	
	private String dsKey;
	
	public QueryRunnerHandler(){
		this.dsKey = defaultDsKey;
	}
	
	public QueryRunnerHandler(String ds_key){
		
		this.dsKey = ds_key;
		
	}
	
	protected QueryRunner runner = new QueryRunner();
	
	public void dealSubmit(Connection conn) throws Exception{
		//处理提交类的请求
	}
	
	public void dealQuery(Connection conn) throws Exception{
		//处理查询类的请求
	}
	
	//模板方法
	public void processSubmit(){
		
		Connection conn = null;
		try {
			//获取连接
			conn = getConnection(dsKey);
			
			//设置为默认不提交，手工控制事务
			conn.setAutoCommit(false);
			
			dealSubmit(conn);//实现此方法进行业务处理
			
			conn.commit();
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
			try {
				DbUtils.rollback(conn);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			
			
		} finally {
			DbUtils.closeQuietly(conn);
		}
	}

	
	//模板方法，查询类的操作
	public void processQuery(){
		Connection conn = null;
		try {
			//获取连接
			conn = getConnection(this.dsKey);
			dealQuery(conn);//实现此方法进行业务处理
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
			
		} finally {
			DbUtils.closeQuietly(conn);
		}
	}
	
	
	//获取连接
	public Connection getConnection(String ds_key) throws Exception{
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		String url = ""+ResourceUtils.getConfigByName(ds_key + ".url");
		String user = ""+ResourceUtils.getConfigByName(ds_key + ".username");
		String password = ""+ResourceUtils.getConfigByName(ds_key + ".password");
		Connection conn = DriverManager.getConnection(url, user, password);
		return conn;
	}
	
}
