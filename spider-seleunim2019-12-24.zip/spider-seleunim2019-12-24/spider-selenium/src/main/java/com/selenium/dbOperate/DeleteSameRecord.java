package com.selenium.dbOperate;

import com.selenium.DButils.DataSourceKey;
import com.selenium.DButils.ResourceUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapListHandler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;

public class DeleteSameRecord {


    public static void main(String[] args) throws SQLException {
        Connection conn = null;
        try {
            conn = DeleteSameRecord.getConnection(DataSourceKey.DEFAULT_KEY);
        } catch (Exception e) {
            e.printStackTrace();
        }
        QueryRunner runner=new QueryRunner();
        List<Map<String, Object>> listMap = runner.query(conn, "select id,url from spider_data_1", new MapListHandler());
        Map<String,Object> tempMap=new HashMap<>();
        Set<Integer> idListNotReal=new HashSet<>();
        for (Map<String, Object> map : listMap) {
            //System.out.println(map.toString());
            Integer id = (Integer) map.get("id");
            idListNotReal.add(id);
            String url = (String) map.get("url");
            //去除重复的url就是把url当做key存入map自然去重。
            tempMap.put(url, map.get("id"));

        }
        System.out.println("总数据量："+idListNotReal.size());
        //System.out.println(tempMap.size());
        Set<Integer> idListReal=new HashSet<>();
        for (Object value : tempMap.values()) {
            idListReal.add((Integer) value);
            //System.out.println(value.toString());
        }
        idListNotReal.removeAll(idListReal);
        System.out.println("重复的数据量："+idListNotReal.size());
        for (Integer integer : idListNotReal) {
            //System.out.println(integer);
            int update = runner.update(conn, "delete from spider_data_1 where id = ? ", integer);
            System.out.println("删除结果："+update);
        }
        //System.out.println(idListNotReal.size());

    }


    //获取连接
    public static java.sql.Connection getConnection(String ds_key) throws Exception {
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        String url = "" + ResourceUtils.getConfigByName(ds_key + ".url");
        String user = "" + ResourceUtils.getConfigByName(ds_key + ".username");
        String password = "" + ResourceUtils.getConfigByName(ds_key + ".password");
        java.sql.Connection conn = DriverManager.getConnection(url, user, password);
        return conn;
    }
}
